<div class="container-fluid">
	<div class="block-header">
		<ol class="breadcrumb breadcrumb-col-pink">
			<li><a href="javascript:void(0);"><i class="material-icons">home</i> Home</a></li>
			<!-- <li class="active"><i class="material-icons">library_books</i> Library</li> -->
		</ol>
	</div>
	<!-- Basic Card -->
	<div class="row clearfix">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="card">
				<div class="header">
					<h2>
						UD. TUGU JAYA MAGETAN 
						
					</h2>
				</div>
				<div class="body"><h4>Update Corona Virus Di Indonesia</h4></div>
				<iframe src="https://covid19.ilmucoding.com/widget" width="100%" scrolling="no" height="250px" style="border:none;"></iframe>

			</div>
			<div class="card">
				<!-- <div class="header">
					<h2>
						UD. TUGU JAYA MAGETAN 
						
					</h2>
				</div> -->
				<div class="body"><h4>Cara Menjadi Pegawai Yang Baik</h4></div>
				<!-- <iframe src="https://covid19.ilmucoding.com/widget" width="100%" scrolling="no" height="250px" style="border:none;"></iframe> -->
				<div style="text-align: center;">	
					<iframe  width="97%" height="440" src="https://www.youtube.com/embed/RU6DAHgbBmo" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
				</div>
			</div>

			<!-- </div>
				<div class="body"><h4>Cara Menjadi Karyawan Yang Baik</h4></div>
				<iframe src="https://covid19.ilmucoding.com/widget" width="100%" scrolling="no" height="250px" style="border:none;"></iframe>

			</div> -->
		</div>
	</div>
</div>